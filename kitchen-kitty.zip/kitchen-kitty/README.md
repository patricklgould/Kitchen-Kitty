# 🚒 Kitchen Kitty

Firehouse kitchen kitty app — grocery lists, meal requests with voting, and kitty payments via Venmo/Zelle.

---

## Step 1 — Set up Supabase

1. Go to your Supabase project dashboard
2. Click **SQL Editor** → **New Query**
3. Paste the contents of `supabase_setup.sql` and click **Run**

That creates the shared `requests` table the crew votes on.

---

## Step 2 — Deploy to Vercel

1. Create a free account at [github.com](https://github.com) if you don't have one
2. Create a new repository called `kitchen-kitty` (make it public)
3. Upload all these files to that repo
4. Go to [vercel.com](https://vercel.com) → Sign up with GitHub
5. Click **Add New Project** → Import your `kitchen-kitty` repo
6. Click **Deploy** — Vercel auto-detects it's a React app

Your app will be live at something like `https://kitchen-kitty.vercel.app`

---

## Step 3 — Share with the crew

Text the Vercel URL to everyone. First time they open it, they pick their name. Done.

---

## Features

- 🔒 **Groceries** — private, stored on each person's phone only
- 🌐 **Requests** — shared live across all crew, upvote/downvote syncs in real time
- 💵 **Kitty** — track balance, pay via Venmo or Zelle deep link
